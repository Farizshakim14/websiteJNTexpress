/**
 * J&T Express - Transportation Monitoring System
 * Single Source of Truth: LIVE SLA COUNTDOWN ENGINE
 */

const SLA_THRESHOLDS = {
    ON_TRACK_RATIO: 0.25,   // remaining > 25% of total SLA -> ON TRACK (🟢)
    NEAR_LATE_RATIO: 0.25,  // remaining <= 25% of total SLA -> NEAR LATE (🟡)
    CRITICAL_RATIO: 0.10,   // remaining <= 10% of total SLA -> CRITICAL (🟠)
    LATE_RATIO: 0           // remaining <= 0 -> LATE (🔴 OVERDUE)
};

const SLACountdownEngine = {
    thresholds: SLA_THRESHOLDS,
    timerId: null,
    registeredNodes: new Map(),

    /**
     * Parses custom date string or timestamp into JavaScript Date object (UTC+7 / Asia/Jakarta standard).
     * Supports formats:
     * - "DD/MM/YYYY HH:mm" (e.g., "22/07/2026 08:00")
     * - "DD/MM HH:mm" (e.g., "02/07 05:15")
     * - "YYYY-MM-DDTHH:mm" / "YYYY-MM-DD HH:mm"
     * - Timestamp numbers or Date instances
     */
    parseTimestamp(str) {
        if (!str) return null;
        if (str instanceof Date) return isNaN(str.getTime()) ? null : str;
        if (typeof str === 'number') return new Date(str);

        const s = String(str).trim();
        if (!s || /^(kosong|belum|nihil|-|—|null|undefined|n\/a)$/i.test(s)) return null;

        // Try standard ISO / Date.parse first if format looks like YYYY-MM-DD
        if (s.match(/^\d{4}-\d{2}-\d{2}/)) {
            const d = new Date(s);
            if (!isNaN(d.getTime())) return d;
        }

        // Handle "DD/MM/YYYY HH:mm" or "DD/MM HH:mm"
        const parts = s.split(' ');
        if (parts.length >= 1 && parts[0].includes('/')) {
            const dateParts = parts[0].split('/');
            const timeParts = parts.length > 1 && parts[1].includes(':') ? parts[1].split(':') : [0, 0];

            let day = parseInt(dateParts[0], 10);
            let month = parseInt(dateParts[1], 10) - 1;
            let year = dateParts[2] ? parseInt(dateParts[2], 10) : new Date().getFullYear();
            let hours = parseInt(timeParts[0], 10);
            let minutes = parseInt(timeParts[1], 10);
            let seconds = timeParts[2] ? parseInt(timeParts[2], 10) : 0;

            if (isNaN(day) || isNaN(month)) return null;
            if (isNaN(hours)) hours = 0;
            if (isNaN(minutes)) minutes = 0;
            if (isNaN(seconds)) seconds = 0;

            const parsed = new Date(year, month, day, hours, minutes, seconds);
            return isNaN(parsed.getTime()) ? null : parsed;
        }

        const d = new Date(s);
        return isNaN(d.getTime()) ? null : d;
    },

    /**
     * Calculates target arrival Date object from departure date + SLA hours.
     */
    calculateTargetTimestamp(departureTimeStr, slaHours) {
        const departureDate = this.parseTimestamp(departureTimeStr);
        if (!departureDate) return null;

        const hours = parseFloat(slaHours);
        if (isNaN(hours) || hours <= 0) return null;

        const targetMs = departureDate.getTime() + (hours * 3600 * 1000);
        return new Date(targetMs);
    },

    /**
     * Calculates SLA status and countdown values for a given trip.
     * Absolute timestamp calculation using Date.now() for 0 drift.
     */
    calculateSLAState(departureTimeStr, slaHours, actualArrivalStr = null) {
        const departureDate = this.parseTimestamp(departureTimeStr);
        const hours = parseFloat(slaHours);

        if (!departureDate || isNaN(hours) || hours <= 0) {
            return {
                status: 'ON_PROGRESS',
                statusCode: 'ON_PROGRESS',
                badgeText: 'ON PROGRESS',
                badgeClass: 'transit',
                badgeSymbol: '●',
                remainingMs: 0,
                remainingFormatted: '--:--:--',
                isOverdue: false,
                isCompleted: false,
                targetDate: null,
                departureDate: null
            };
        }

        const totalSlaMs = hours * 3600 * 1000;
        const targetDate = new Date(departureDate.getTime() + totalSlaMs);
        const actualArrivalDate = this.parseTimestamp(actualArrivalStr);

        // If completed (actual arrival available)
        if (actualArrivalDate) {
            const delayMs = actualArrivalDate.getTime() - targetDate.getTime();
            const isLate = delayMs > 0;

            return {
                status: 'COMPLETED',
                statusCode: isLate ? 'COMPLETED_LATE' : 'COMPLETED_ON_TIME',
                badgeText: isLate ? 'LATE' : 'ON TIME',
                badgeClass: isLate ? 'red' : 'green',
                badgeSymbol: isLate ? '🔴' : '🟢',
                remainingMs: 0,
                remainingFormatted: 'COMPLETED',
                actualArrivalFormatted: this.formatTimeOnly(actualArrivalDate),
                targetFormatted: this.formatTimeOnly(targetDate),
                delayFormatted: delayMs > 0 ? this.formatMsDuration(delayMs) : '00:00:00',
                isOverdue: isLate,
                isCompleted: true,
                targetDate,
                departureDate
            };
        }

        // Live Active Countdown calculation using Date.now()
        const nowMs = Date.now();
        const remainingMs = targetDate.getTime() - nowMs;
        const remainingRatio = remainingMs / totalSlaMs;

        let statusCode = 'ON_TRACK';
        let badgeText = 'ON TRACK';
        let badgeClass = 'green';
        let badgeSymbol = '🟢';
        let isOverdue = false;

        if (remainingMs <= 0) {
            statusCode = 'LATE';
            badgeText = 'LATE';
            badgeClass = 'red';
            badgeSymbol = '🔴';
            isOverdue = true;
        } else if (remainingRatio <= SLA_THRESHOLDS.CRITICAL_RATIO) {
            statusCode = 'CRITICAL';
            badgeText = 'CRITICAL';
            badgeClass = 'orange';
            badgeSymbol = '🟠';
        } else if (remainingRatio <= SLA_THRESHOLDS.NEAR_LATE_RATIO) {
            statusCode = 'NEAR_LATE';
            badgeText = 'NEAR LATE';
            badgeClass = 'yellow';
            badgeSymbol = '🟡';
        }

        const remainingFormatted = isOverdue 
            ? `OVERDUE ${this.formatMsDuration(Math.abs(remainingMs))}`
            : this.formatMsDuration(remainingMs);

        return {
            status: statusCode,
            statusCode,
            badgeText,
            badgeClass,
            badgeSymbol,
            remainingMs,
            remainingRatio,
            remainingFormatted,
            isOverdue,
            isCompleted: false,
            targetDate,
            departureDate
        };
    },

    /**
     * Formats milliseconds duration into HH:MM:SS format.
     */
    formatMsDuration(ms) {
        if (isNaN(ms) || ms < 0) ms = 0;
        const totalSec = Math.floor(ms / 1000);
        const hours = Math.floor(totalSec / 3600);
        const minutes = Math.floor((totalSec % 3600) / 60);
        const seconds = totalSec % 60;

        const pad = (num) => String(num).padStart(2, '0');
        return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    },

    formatTimeOnly(date) {
        if (!date) return '-';
        const pad = (num) => String(num).padStart(2, '0');
        const dd = pad(date.getDate());
        const mm = pad(date.getMonth() + 1);
        return `${dd}/${mm} ${pad(date.getHours())}:${pad(date.getMinutes())} WIB`;
    },

    _isScrolling: false,
    _scrollResumeTimer: null,
    _scrollListenerBound: false,

    _bindScrollGuard() {
        if (this._scrollListenerBound || typeof window === 'undefined') return;
        this._scrollListenerBound = true;
        const onScroll = () => {
            this._isScrolling = true;
            if (this._scrollResumeTimer) clearTimeout(this._scrollResumeTimer);
            this._scrollResumeTimer = setTimeout(() => {
                this._isScrolling = false;
            }, 150);
        };
        window.addEventListener('scroll', onScroll, { passive: true, capture: true });
    },

    /**
     * Single Centralized Global Timer Controller
     */
    startGlobalTimer() {
        this._bindScrollGuard();
        if (this.timerId) return; // Already running
        console.log('[SLA COUNTDOWN ENGINE] Starting Centralized Global 1000ms Clock Timer...');
        this.timerId = setInterval(() => {
            if (this._isScrolling || (typeof document !== 'undefined' && document.hidden)) return;
            this.tick();
        }, 1000);
    },

    stopGlobalTimer() {
        if (this.timerId) {
            console.log('[SLA COUNTDOWN ENGINE] Stopping Centralized Global Clock Timer...');
            clearInterval(this.timerId);
            this.timerId = null;
        }
    },

    /**
     * Executed every 1000ms tick. Iterates through all registered UI nodes or dynamic SLA elements.
     */
    tick() {
        // 1. Registered DOM Elements
        if (this.registeredNodes.size > 0) {
            this.registeredNodes.forEach((config, elementId) => {
                const el = document.getElementById(elementId);
                if (!el || !document.body.contains(el)) {
                    // Clean up unmounted elements
                    this.registeredNodes.delete(elementId);
                    return;
                }

                const state = this.calculateSLAState(config.departure, config.slaHours, config.actualArrival);
                this.updateElementUI(el, state, config);
            });
        }

        // 2. Dynamic Declarative Elements with data-sla-departure
        const declarativeEls = document.querySelectorAll('[data-sla-departure]');
        declarativeEls.forEach(el => {
            const departure = el.getAttribute('data-sla-departure');
            const slaHours = el.getAttribute('data-sla-hours');
            const actualArrival = el.getAttribute('data-sla-arrival');

            if (actualArrival && actualArrival !== '-' && el.getAttribute('data-sla-done-rendered') === actualArrival) {
                return;
            }

            const state = this.calculateSLAState(departure, slaHours, actualArrival);
            this.updateDeclarativeElementUI(el, state);
            if (state.isCompleted && actualArrival) {
                el.setAttribute('data-sla-done-rendered', actualArrival);
            } else {
                el.removeAttribute('data-sla-done-rendered');
            }
        });
    },

    /**
     * Registers a DOM element ID for live SLA countdown updates.
     */
    registerElement(elementOrId, config) {
        const id = typeof elementOrId === 'string' ? elementOrId : elementOrId.id;
        if (!id) return;

        this.registeredNodes.set(id, config);
        
        // Immediate first render
        const el = typeof elementOrId === 'string' ? document.getElementById(elementOrId) : elementOrId;
        if (el) {
            const state = this.calculateSLAState(config.departure, config.slaHours, config.actualArrival);
            this.updateElementUI(el, state, config);
        }

        this.startGlobalTimer();
    },

    unregisterElement(elementOrId) {
        const id = typeof elementOrId === 'string' ? elementOrId : elementOrId.id;
        if (id) this.registeredNodes.delete(id);
    },

    clearRegisteredElements() {
        this.registeredNodes.clear();
    },

    /**
     * Updates programmatic registered element UI.
     * ANTI-FLICKER: Gunakan textContent/className saja.
     */
    updateElementUI(el, state, config = {}) {
        if (!el) return;

        const remainingEl = config.remainingSelector ? el.querySelector(config.remainingSelector) : el;
        const statusEl = config.statusSelector ? el.querySelector(config.statusSelector) : null;

        if (remainingEl) {
            let newText = '', newClass = '';
            if (state.status === 'DATA_ERROR') {
                newText  = 'N/A';
                newClass = 'sla-remaining-cell text-dim';
            } else if (state.isCompleted) {
                newText  = 'COMPLETED';
                newClass = 'sla-remaining-cell completed';
            } else if (state.isOverdue) {
                newText  = state.remainingFormatted;
                newClass = 'sla-remaining-cell overdue font-bold';
            } else {
                newText  = state.remainingFormatted;
                newClass = 'sla-remaining-cell ' + state.badgeClass + ' font-bold';
            }
            if (remainingEl.textContent !== newText) remainingEl.textContent = newText;
            if (remainingEl.className   !== newClass) remainingEl.className   = newClass;
        }

        if (statusEl) {
            const newClass   = 'badge-status sla-badge-' + state.badgeClass;
            const newText    = state.badgeText;
            if (statusEl.className !== newClass) statusEl.className = newClass;
            // Hanya update isi dot + label — jangan hancurkan seluruh innerHTML
            let labelEl = statusEl.querySelector('.pill-label');
            if (!labelEl) {
                statusEl.innerHTML = '<span class="dot">\u25cf</span>\u00a0<span class="pill-label">' + newText + '</span>';
            } else {
                if (labelEl.textContent !== newText) labelEl.textContent = newText;
            }
        }
    },

    /**
     * Updates declarative element UI ([data-sla-departure]).
     * ANTI-FLICKER: Hanya sentuh DOM jika nilai benar-benar berubah.
     * Tidak gunakan innerHTML untuk status pill — update className dan textContent saja.
     */
    updateDeclarativeElementUI(el, state) {
        if (!el) return;

        // ── 1. Countdown timer ───────────────────────────────────────────────
        const countdownEl = el.querySelector('.sla-live-countdown');
        if (countdownEl) {
            if (state.isCompleted) {
                if (countdownEl.style.display !== 'none') countdownEl.style.display = 'none';
            } else {
                if (countdownEl.style.display === 'none') countdownEl.style.display = '';
                const newText  = state.remainingFormatted;
                const newClass = 'sla-live-countdown sla-rem-' + state.badgeClass;
                // Guard: jangan sentuh DOM kalau tidak berubah
                if (countdownEl.textContent !== newText) {
                    countdownEl.textContent = newText;
                }
                if (countdownEl.className !== newClass) {
                    countdownEl.className = newClass;
                }
            }
        }

        // ── 2. Status pill ───────────────────────────────────────────────────
        const statusContainer = el.querySelector('.sla-live-status') || el.querySelector('.mon-status-group') || el.querySelector('.mon-status-cell');
        if (statusContainer) {
            if (state.isCompleted) {
                const isLate = state.isOverdue;
                const pillClass = isLate ? 'mon-pill-late' : 'mon-pill-ontime';
                const badgeClass = isLate ? 'mon-pill-badge-late-completed' : 'mon-pill-badge-completed';
                const textLabel = isLate ? 'LATE' : 'ON TIME';
                const badgeText = isLate ? 'COMPLETED' : '✓ COMPLETED';
                const expectedHtml = `<div class="mon-status-row"><span class="${pillClass}"><span class="dot">●</span> ${textLabel}</span><span class="${badgeClass}">${badgeText}</span></div>`;
                if (statusContainer.innerHTML !== expectedHtml) {
                    statusContainer.className = 'mon-status-cell';
                    statusContainer.innerHTML = expectedHtml;
                }
            } else {
                // Cari existing pill — jangan recreate jika hanya class/text yang berubah
                let pill = statusContainer.querySelector('.sla-status-pill');
                const newPillClass = 'sla-status-pill ' + state.badgeClass;
                const newBadgeText = state.badgeText; // teks saja, tanpa emoji

                if (!pill) {
                    // Buat pill pertama kali (saat row baru muncul)
                    statusContainer.className = 'sla-live-status';
                    pill = document.createElement('span');
                    pill.className = newPillClass;
                    const dot = document.createElement('span');
                    dot.className = 'dot';
                    dot.textContent = '\u25cf';
                    const label = document.createElement('span');
                    label.className = 'pill-label';
                    label.textContent = newBadgeText;
                    pill.appendChild(dot);
                    pill.appendChild(document.createTextNode('\u00a0'));
                    pill.appendChild(label);
                    statusContainer.innerHTML = '';
                    statusContainer.appendChild(pill);
                } else {
                    // Update class hanya jika beda
                    if (pill.className !== newPillClass) {
                        pill.className = newPillClass;
                    }
                    // Update label teks hanya jika beda
                    const labelEl = pill.querySelector('.pill-label');
                    if (labelEl) {
                        if (labelEl.textContent !== newBadgeText) {
                            labelEl.textContent = newBadgeText;
                        }
                    } else {
                        // Fallback: jika struktur pill lama belum punya .pill-label
                        const newHtml = '<span class="dot">\u25cf</span>\u00a0<span class="pill-label">' + newBadgeText + '</span>';
                        if (statusContainer.innerHTML.indexOf(newBadgeText) === -1 ||
                            pill.className !== newPillClass) {
                            pill.className = newPillClass;
                            pill.innerHTML = newHtml;
                        }
                    }
                }
            }
        }
    }
};

// Auto-start timer on load & export for CJS environments
if (typeof window !== 'undefined') {
    window.SLACountdownEngine = SLACountdownEngine;
    window.SLA_THRESHOLDS = SLA_THRESHOLDS;
    document.addEventListener('DOMContentLoaded', () => {
        SLACountdownEngine.startGlobalTimer();
    });
}
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SLACountdownEngine;
}
